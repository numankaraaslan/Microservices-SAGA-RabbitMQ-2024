#!/bin/bash

# ./image_loader_thing.sh
# If permission denied: chmod +x image_loader_thing.sh

# List of image names to load into Minikube
IMAGES=(
  ab-eureka:latest
  ab-config-server:latest
  ab-gateway:latest
  ab-userservice:latest
  ab-userservice-failover:latest
  ab-activityservice:latest
  ab-activityservice-failover:latest
  ab-paymentservice:latest
  ab-paymentservice-failover:latest
  ab-mailservice:latest
  ab-website:latest
  ab-util:latest
)

echo "📦 Loading images into Minikube..."

for image in "${IMAGES[@]}"; do
  echo "➡️  Loading $image ..."
  minikube image load "$image"
done

echo "✅ All images loaded successfully into Minikube!"

